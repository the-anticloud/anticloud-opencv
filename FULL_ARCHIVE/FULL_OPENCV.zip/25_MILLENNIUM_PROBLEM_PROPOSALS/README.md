# 25 Millennium Problem Proposals

**Project:** OPENCV
**Upstream:** https://github.com/opencv/opencv

Content specific to OPENCV in category CAMERAS.
